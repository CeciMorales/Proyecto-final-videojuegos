﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Vida : MonoBehaviour {

    [SerializeField]
    private float health;
    [SerializeField]
    private float maxHealth;
    [SerializeField]
    public Image healthBar;
    public GameObject FlavioLleno;
    public GameObject FlavioMedio;
    public GameObject FlavioMuerto;


    // Use this for initialization
    void Start () {
        health = maxHealth;
    }
	
	void Update () {
        
        if (health <= maxHealth && health >10)
        {

            FlavioMuerto.SetActive(false);
            FlavioMedio.SetActive(false);
            FlavioLleno.SetActive(true);
        }
        if (health <= 10 && health > 1)
        {
            
            FlavioMuerto.SetActive(false);
            FlavioMedio.SetActive(true);
            FlavioLleno.SetActive(false);
        }
        if (health <= 1)
        {

            FlavioMuerto.SetActive(true);
            FlavioMedio.SetActive(false);
            FlavioLleno.SetActive(false);
        }
    }
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Enemy"))
        {
            health = health - 1;
            healthBar.fillAmount = (1 / maxHealth) * health;
        }

        if (collision.gameObject.CompareTag("OlmecaRoja"))
        {
            health = health - 2;
            healthBar.fillAmount = (1 / maxHealth) * health;
        }
        if (collision.gameObject.CompareTag("Picos"))
        {

            health = health - 2;
            healthBar.fillAmount = (1 / maxHealth) * health;
        }

        if(health<= 0)
        {
            Destroy(gameObject);
            
        }
    }
}
