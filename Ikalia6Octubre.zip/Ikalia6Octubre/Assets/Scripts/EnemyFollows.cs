﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFollows : MonoBehaviour {


    public float speed = 10;
    private Transform target; //player

    public bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask whatIsGround;


    // Use this for initialization
    void Start () {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
		

	}
	
	// Update is called once per frame
	void Update () {
       

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, whatIsGround);

        if (isGrounded) {

            if (Vector2.Distance(transform.position, target.position) < 30 && Vector2.Distance(transform.position, target.position) > 3)
            {
                //(from, to)
                transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

            }



        }

       
        
		
	}
}
