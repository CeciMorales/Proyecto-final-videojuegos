﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public int health = 20;
    bool hasCoolDown = false;
    public double timeLeft =1;
    public double interval = 0.3;
    bool playerHit = false;
    int counterCoins;

    public void Update()

    {
        //ve si no lo han golpeado
        returnPlayerHit();

        /*if(counterCoins == 8)
        {
            //activar el tlacuache especial 1
        }else if(counterCoins == 10)
        {
            //activar tlacuache especial 1 y 2
        }else if(counterCoins == 15)
        {
            //activar tlacuache especial 1,2 y3
        }
        */



    }

    //public SceneChanger changeScene;
    // Use this for initialization

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            //transform.position.y + 2 < collision.transform.position.y

            if (collision.transform.position.y+2 > transform.position.y)
            {
                Debug.Log(collision.gameObject.tag);

                colorPlayerHit();
                movePlayerHit();


            }





        }

        if (collision.gameObject.CompareTag("Picos"))
        {

            Debug.Log("picopico");
            colorPlayerHit();
        }
    }

    void movePlayerHit()

    {

        Vector3 temp = new Vector3(-3.0f, 0, 0);

        if (Input.GetAxis("Horizontal") < 0)
        {
            this.transform.position += -(temp);

        }else if (Input.GetAxis("Horizontal") > 0)
        {
            this.transform.position += temp;
        }
        
        
    }



    void colorPlayerHit()
    {

        GetComponent<SpriteRenderer>().color = new Color32(255, 190, 210, 255);
        playerHit = true;


    }

    void returnPlayerHit()
    {
        if (playerHit)
        {

            timeLeft -= Time.deltaTime;
            if (timeLeft < 0)
            {
                playerHit = false;
                GetComponent<SpriteRenderer>().color = new Color32(255, 255, 255, 255);

            }
        }
        else
        {
            timeLeft = 1;

        }

    }




    void SubstractHealth()
    {
        if (!hasCoolDown)
        {
            if (health > 0)
            {
                health--;
                hasCoolDown = true;
                StartCoroutine(CoolDown());

            }

            if (health <= 0)
            {
                //changeScene.ChangeSceneTo("SampleScene");
            }
            
        }
    }

    IEnumerator CoolDown()
    {
        yield return new WaitForSeconds(0.5f);
        hasCoolDown = false;
        StopCoroutine(CoolDown());
    }

    /*void EmptyHearts()
    {
        for (int i = 0; i < hearts.Length; i++)
        {
            if (health - 1 < i)
            {
                hearts[i].gameObject.SetActive(false);
            }
        }
    }*/

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Coin")
        {
            //collectablePart.transform.position = transform.position; //darle la posicion del coleccionable actual
            //collectablePart.Play();//Salen las particulas
            //collectableAudio.Play(); //Suene el sonido
            //desaparece el item
            counterCoins += 1;
            Debug.Log(counterCoins);
            //collectableQuantity++;
            //collectableText.text = collectableQuantity.ToString(); //actualizar el texto
        }


        if (col.gameObject.CompareTag("CheckPointBoss"))
        {
            Debug.Log(col.gameObject.tag);
        }

    }
}

/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {
    public int health = 3;
    public Image[] hearts;
    bool hasCoolDown = false;


    //public SceneChanger changeScene;
    // Use this for initialization

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy") || collision.gameObject.CompareTag("Picos"))
        {
            if (GetComponent<PlayerMovement>().isGrounded)
            {
                SubstractHealth();
            }
        }
    }
    void SubstractHealth()
    {
        if (!hasCoolDown)
        {
            if (health > 0)
            {
                health--;
                hasCoolDown = true;
                StartCoroutine(CoolDown());

            }
            
            if (health <= 0)
                {
                //changeScene.ChangeSceneTo("SampleScene");
                }
            EmptyHearts();
        }
    }

    IEnumerator CoolDown()
    {
        yield return new WaitForSeconds(0.5f);
        hasCoolDown = false;
        StopCoroutine(CoolDown());
    }

    void EmptyHearts()
    {
        for( int i = 0; i< hearts.Length; i++)
        {
            if(health-1 < i)
            {
                hearts[i].gameObject.SetActive(false);
            }
        }
    }
}
*/
