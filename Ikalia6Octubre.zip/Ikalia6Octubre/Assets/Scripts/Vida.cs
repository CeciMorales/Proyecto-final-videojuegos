﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vida : MonoBehaviour {


    public int maxHealth = 20;
    public int currentHealth;
    
	// Use this for initialization
	void Start () {
        currentHealth = maxHealth;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Enemy"))
        {
            currentHealth = currentHealth - 1;
    
        }

        if (collision.gameObject.CompareTag("OlmecaRoja"))
        {
            currentHealth = currentHealth - 2;

        }
        if (collision.gameObject.CompareTag("Picos"))
        {
            currentHealth = currentHealth - 3;

        }

        if(currentHealth<= 0)
        {
            gameObject.SetActive(false);
        }
    }
}
