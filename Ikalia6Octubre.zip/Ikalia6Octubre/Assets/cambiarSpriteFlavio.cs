﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cambiarSpriteFlavio : MonoBehaviour {

    public Image imagenUI;
	// Use this for initialization
	void Start () {
        imagenUI = GameObject.Find("ImagenFlavio").GetComponent<Image>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            imagenUI.sprite = Resources.Load<Sprite>("Sprites/lifeBar2");
        }
	}
}
